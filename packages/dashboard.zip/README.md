# 340i native dashboard update

ShiftDeck targets a 20 ms RPM polling loop, with vehicle speed sampled every 65 ms. It schedules a screen update every 16 ms while visible and interpolates RPM for up to 50 ms after a new reading. Fresh measured values still drive the shift alert directly.

BoostDeck targets a 35 ms fast scan for boost, AFR, timing, rail pressure and oil pressure. Temperatures retain a 2 second schedule and Active Ethanol a 5 second schedule. A scan can take longer when the DME is slow or another app needs the gateway.

Both apps offer Imperial and Metric under OPTIONS. ShiftDeck uses mph or km/h. BoostDeck uses psi and Fahrenheit or bar and Celsius. MHD+ Suite shows On under Max Cooling. Its existing live-RPM condition and command are retained.

The bundled Engine Fault Codes also includes the earlier clear-response and extended-session improvements. Follow AgentReadMe.md in the GitHub repository for setup and verification. Restart iDrive while parked after verifying the files.

The four workers (`boostdeck-collector-qnx`, `shift-deck-qnx`, `mhd-maps-qnx`, `engine-codes-qnx`) include the MOST fallback from #9. When the HSFZ gateway is unreachable, for example with nothing plugged into OBD, they reach the DME through the head unit's own UDS tunnel over MOST. See `source/docs/MOST.md`. The plugin libraries are unchanged.
